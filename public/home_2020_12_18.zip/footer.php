        <footer>
            <div class="container">
                <div class="row">
                    <p class="col-md-12 text-center">
                        <a href="https://www.facebook.com/clarkesg/?fref=ts" title="">
                            <img src="<?= base_url() ?>public/img/redes/facebook.svg" width="32" alt="">
                        </a>
                        <!--<a href="" title="">
                            <img src="<?= base_url() ?>public/img/redes/twitter.svg" width="32" alt="">
                        </a>-->
                    </p>
                    <p class="col-md-12 menu">
                        <a href="<?= base_url() ?>" title="">INICIO</a>
                        <a href="<?= base_url() ?>quienes-somos.php" title="">QUIENES SOMOS</a>
                        <a href="<?= base_url() ?>descubre-clark.php" title="">DESCUBRE CLARK</a>
                        <a href="<?= base_url() ?>contactanos.php" title="">CONTÁCTANOS</a>
                    </p>
                    <p class="col-md-12 text-center info">©2016 ESG PERU - ENVASADORA SAN GABRIEL SRL, INC. TODOS LOS DERECHOS RESERVADOS.</p>
                    <p class="col-md-12 text-center info">POLÍTICA DE PRIVACIDAD ESG, INC© 2015 ESG, INC. TODOS LOS DERECHOS RESERVADOS. </p>
                </div>
            </div>
        </footer>