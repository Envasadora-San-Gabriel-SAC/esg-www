        <nav class="menu-responsive">
            <ul class="nav" id="tree1">
                <li><a href="<?=base_url();?>quienes-somos.php">quienes somoszz</a></li>
                <li>
                    <a>productos y servicios</a>
                    <ul class="list-unstyled" >
                        <li>
                            <a href="distribucion-y-comercializacion-de-combustibles.php">
                                Distribución y comercialización de combustibles 
                            </a>
                            <ul class="list-unstyled">
                                <li class="dropdown-submenu">
                                    <a href="tanques-estacionarios.php">abastecimiento a tanques estacionarios</a>
                                </li>
                                <li class="dropdown-submenu">
                                    <a href="maquinaria-pesada.php">abastecimiento a maquinaria pesada</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a>pinturas clark</a>
                            <ul class="list-unstyled">
                                <li >
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Latex y Bases</a>
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="megalatex.php">Megalatex</a>
                                        </li>
                                        <li>
                                            <a href="perfect-mate.php">perfect mate</a>
                                        </li>
                                        <li>
                                            <a href="satinado.php">satinado</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">BASES</a>
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="imprimante.php">imprimante</a>
                                        </li>
                                        <li>
                                            <a href="temple.php">temple</a>
                                        </li>
                                        <li>
                                            <a href="temple-fino.php">temple fino</a>
                                        </li>
                                        <li>
                                            <a href="pasta-mural.php">pasta mural</a>
                                        </li>
                                        <li>
                                            <a href="sellador.php">sellador</a>
                                        </li>
                                        <li>
                                            <a href="sellador-acrilico.php">sellador acrílico</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">ESMALTES SINTÉTICOS</a>
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="esmalte-sintetico.php">ESMALTES SINTÉTICOS</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">GLOSs</a>
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="gloss.php">GLOSS</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">OLEO MATE</a>
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="oleo-mate.php">OLEO MATE</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">TTP115</a>
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="ttp15">TTP 115</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">anticorrosivo</a>
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="esmalte-anticorrosivo.php">esmalte anticorrosivo</a>
                                        </li>
                                        <li>
                                            <a href="zincromato-industrial.php">zincromato industrial</a>
                                        </li>
                                        <li>
                                            <a href="zincromato-automotriz.php">zincromato automotriz</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">PINTURA TRÁFICO</a>
                                    <ul class="list-unstyled">
                                        <li>
                                            <a href="trafico-alto-transito.php">TRÁFICO ALTO TRANSITO</a>
                                        </li>
                                        <li>
                                            <a href="trafico-alto-transito-ttp.php">TRÁFICO ALTO TRANSITO TTP</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li><a href="servicios-de-pintado-y-revestimiento-de-tanques-y-otro.php">Servicios de Pintado y revestimiento de tanques y otro</a></li>
                        <li><a href="productos-quimico-resinas-moromeros-solventes-y-diluyentes.php">Productos químicos: resinas, monomero, solventes y diluyentes</a></li>
                    </ul>
                </li>
                <li><a href="<?=base_url();?>descubre-clark.php">descubre clark</a></li>
                <li><a href="<?=base_url();?>contactanos.php">contactanos</a></li>
            </ul>
        </nav>